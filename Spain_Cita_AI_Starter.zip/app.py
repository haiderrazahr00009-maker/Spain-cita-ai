import os, json, hmac, hashlib, sqlite3, requests
from datetime import datetime
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", "change-this-secret-before-deploying")
DB = os.getenv("DATABASE_PATH", "cita_requests.db")
GRAPH_VERSION = os.getenv("GRAPH_VERSION", "v23.0")

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            wa_id TEXT,
            name TEXT,
            language TEXT,
            appointment_type TEXT,
            province TEXT,
            preferred_date TEXT,
            status TEXT DEFAULT 'new',
            notes TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            wa_id TEXT,
            direction TEXT,
            body TEXT
        )""")

def log_message(wa_id, direction, body):
    with db() as c:
        c.execute("INSERT INTO messages(created_at,wa_id,direction,body) VALUES(?,?,?,?)",
                  (datetime.utcnow().isoformat(), wa_id, direction, body[:3000]))

def send_whatsapp(to, body):
    token = os.getenv("WHATSAPP_TOKEN")
    phone_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID")
    if not token or not phone_id:
        app.logger.warning("WhatsApp credentials missing; reply not sent.")
        return False
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{phone_id}/messages"
    r = requests.post(url, headers={"Authorization": f"Bearer {token}",
        "Content-Type": "application/json"},
        json={"messaging_product":"whatsapp","to":to,"type":"text",
              "text":{"body":body}}, timeout=20)
    r.raise_for_status()
    return True

def ai_reply(message, language_hint=""):
    # Optional OpenAI-compatible Responses API. Without a key, use a safe guided reply.
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return ("¡Hola! Gracias por contactar con Spain Cita AI. "
                "Para ayudarte, envía: tipo de cita, provincia y fecha preferida. "
                "No compartas pasaporte, NIE, contraseñas ni códigos por este chat.")
    try:
        r = requests.post("https://api.openai.com/v1/responses",
            headers={"Authorization": f"Bearer {key}", "Content-Type":"application/json"},
            json={"model":os.getenv("OPENAI_MODEL","gpt-4.1-mini"),
                  "input":[
                    {"role":"system","content":
                     "You are a customer-support assistant for a Spain appointment request service. "
                     "Reply in the customer's language (Urdu, English, or Spanish). Collect only "
                     "appointment type, province/city, preferred date, and contact name. Never claim "
                     "availability or a booking unless verified by an authorized official confirmation. "
                     "Do not request passport scans, passwords, one-time codes, or sensitive identity "
                     "documents in chat. Explain that official booking is completed by the customer or "
                     "with their explicit approval through the official portal. Be concise and polite."},
                    {"role":"user","content":message}
                  ]}, timeout=25)
        r.raise_for_status()
        data = r.json()
        for item in data.get("output", []):
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    return part.get("text","")
    except Exception as e:
        app.logger.exception("AI response failed: %s", e)
    return ("Gracias por tu mensaje. Indica por favor el tipo de cita, la provincia "
            "y la fecha preferida. Te confirmaremos los siguientes pasos.")

def handle_incoming(wa_id, text):
    log_message(wa_id, "incoming", text)
    reply = ai_reply(text)
    # Store a simple request record for admin follow-up; detailed fields can be updated in dashboard.
    with db() as c:
        c.execute("INSERT INTO requests(created_at,wa_id,notes,status) VALUES(?,?,?,?)",
                  (datetime.utcnow().isoformat(), wa_id, text[:1500], "needs_review"))
    try:
        send_whatsapp(wa_id, reply)
        log_message(wa_id, "outgoing", reply)
    except Exception:
        app.logger.exception("Could not send WhatsApp reply")

@app.route("/")
def home():
    if not session.get("admin"):
        return redirect(url_for("login"))
    with db() as c:
        rows = c.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("dashboard.html", rows=rows)

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        if request.form.get("password") == os.getenv("ADMIN_PASSWORD", "change-me"):
            session["admin"] = True
            return redirect(url_for("home"))
        flash("پاس ورڈ درست نہیں۔")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/request/<int:rid>/status", methods=["POST"])
def update_status(rid):
    if not session.get("admin"):
        return redirect(url_for("login"))
    status = request.form.get("status","new")
    if status not in ("new","needs_review","customer_contacted","officially_confirmed","closed"):
        status = "needs_review"
    with db() as c:
        c.execute("UPDATE requests SET status=? WHERE id=?", (status,rid))
    return redirect(url_for("home"))

@app.route("/webhook", methods=["GET","POST"])
def webhook():
    if request.method == "GET":
        verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN","")
        if request.args.get("hub.verify_token") == verify_token:
            return request.args.get("hub.challenge",""), 200
        return "Verification failed", 403

    # Optional signature verification. Configure APP_SECRET in Meta and environment.
    app_secret = os.getenv("META_APP_SECRET")
    if app_secret:
        signature = request.headers.get("X-Hub-Signature-256","")
        expected = "sha256=" + hmac.new(app_secret.encode(), request.get_data(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return "Invalid signature", 403

    payload = request.get_json(silent=True) or {}
    try:
        for entry in payload.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                for msg in value.get("messages", []):
                    wa_id = msg.get("from")
                    text = msg.get("text",{}).get("body","")
                    if wa_id and text:
                        handle_incoming(wa_id, text)
    except Exception:
        app.logger.exception("Webhook processing failed")
        return jsonify({"ok":False}), 500
    return jsonify({"ok":True})

@app.route("/health")
def health():
    return jsonify({"status":"ok","service":"Spain Cita AI"})

init_db()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5000")), debug=False)
