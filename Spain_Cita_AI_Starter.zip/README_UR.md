# Spain Cita AI — ابتدائی WhatsApp کسٹمر سپورٹ سسٹم

یہ ایک ابتدائی قابلِ ترمیم پروجیکٹ ہے۔ یہ WhatsApp Cloud API کے ذریعے آنے والے متنی پیغامات وصول کرتا ہے، اختیاری AI جواب بناتا ہے، اور درخواستیں مقامی SQLite ڈیٹابیس اور ایڈمن ڈیش بورڈ میں محفوظ کرتا ہے۔

## یہ کیا کرتا ہے؟
- WhatsApp Cloud API webhook سے incoming text وصول کرتا ہے۔
- اختیاری OpenAI API کے ذریعے اردو، انگریزی یا ہسپانوی میں جواب بناتا ہے۔
- کسٹمر کے پیغام اور WhatsApp ID کو ڈیش بورڈ میں محفوظ کرتا ہے۔
- ایڈمن درخواست کی حیثیت اپڈیٹ کر سکتا ہے۔

## یہ کیا نہیں کرتا؟
- یہ سرکاری Extranjería/Policía پورٹل سے دستیابی خودکار طور پر نہیں پڑھتا۔
- یہ سرکاری اپائنٹمنٹ خودکار طور پر بک نہیں کرتا۔
- CAPTCHA، OTP یا شناختی تصدیق کو بائی پاس نہیں کرتا۔
- WhatsApp یا AI API کی فیس/اکاؤنٹ فراہم نہیں کرتا۔

## چلانے کا طریقہ
1. Python 3.11 یا اس سے نیا ورژن اور hosting/server درکار ہے۔
2. پروجیکٹ فولڈر میں:
   `pip install -r requirements.txt`
3. `.env.example` کی نقل `.env` کے نام سے بنائیں اور اپنے secrets درج کریں۔
4. `python app.py` چلائیں۔
5. عارضی طور پر local test کے لیے `/health` کھولیں؛ WhatsApp webhook کے لیے HTTPS public hosting ضروری ہے۔
6. Meta Developer dashboard میں WhatsApp webhook URL `https://YOUR-DOMAIN/webhook` رکھیں اور verify token وہی درج کریں جو `.env` میں ہے۔ `messages` webhook field subscribe کریں۔
7. WhatsApp Cloud API کا access token اور Phone Number ID `.env` میں درج کریں۔

## سیکیورٹی
- `.env` کسی کو نہ بھیجیں اور GitHub پر اپلوڈ نہ کریں۔
- مضبوط `FLASK_SECRET` اور `ADMIN_PASSWORD` استعمال کریں۔
- پاسپورٹ، NIE، پاس ورڈ، OTP یا شناختی دستاویزات WhatsApp chat یا عام Google Sheet میں نہ لیں/محفوظ کریں۔
- کسٹمر کو واضح بتائیں کہ آپ اس کی درخواست وصول کر رہے ہیں؛ سرکاری بکنگ کی تصدیق صرف سرکاری confirmation سے ہوگی۔
- اصل استعمال سے پہلے privacy notice، قانونی بنیاد، ڈیٹا retention اور صارف کی رضامندی کا جائزہ لیں۔ EU/Spain کے صارفین کے ڈیٹا کے لیے GDPR ذمہ داریاں لاگو ہو سکتی ہیں۔
- Meta/WhatsApp Business اکاؤنٹ اور سرکاری بکنگ کی اجازت متعلقہ اکاؤنٹ کے مجاز بالغ/کاروباری منتظم کے ذریعے مکمل ہونی چاہیے۔

## اہم
یہ starter implementation ہے، deployed service نہیں۔ اسے انٹرنیٹ پر چلانے، Meta credentials شامل کرنے، اور مکمل test کرنے کے بعد ہی حقیقی صارفین کے لیے استعمال کریں۔
